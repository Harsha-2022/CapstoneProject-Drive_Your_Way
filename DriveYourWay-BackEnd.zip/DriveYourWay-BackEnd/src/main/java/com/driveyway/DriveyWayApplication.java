package com.driveyway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriveyWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriveyWayApplication.class, args);
	}

}
